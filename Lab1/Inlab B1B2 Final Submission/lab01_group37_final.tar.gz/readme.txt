Group Number - 37


Honor Code - 
I pledge by my honor that I have not received or given any unauthorized help for this assignment.


Contributions - 
(Meet Taraviya, mtaraviya, 150050002) - 100%
(Akash Trehan, atrehan, 150050031) - 100%
(Rohit Kumar Jena, rohitrango, 150050061) - 100%


Citations - 
-> Matrix to Vector conversion - http://stackoverflow.com/questions/5817853/matrix-to-vector-conversion-in-matlab

-> Vector to Matrix conversion - http://stackoverflow.com/questions/10432412/vector-to-matrix-in-octave

-> Modulus of Matrix - https://www.gnu.org/software/octave/doc/v4.0.1/Utility-Functions.html#XREFmod

-> If statement syntax - https://www.gnu.org/software/octave/doc/v4.0.1/The-if-Statement.html

-> Switch statement syntax - https://www.gnu.org/software/octave/doc/v4.0.0/The-switch-Statement.html

-> Comparison operators - https://www.gnu.org/software/octave/doc/v4.0.1/Comparison-Ops.html


Reflection Essay - 

We first solved B2 and found it pretty easy. This also helped us find a nice solution to B1 without using the table but we noticed that the question compulsorily wanted us to use the table. Using lots of if statements, we finally arrived at the solution for B1. We wanted to check our solutions so we made a function to generate all possible 3*3 matrices and pass them to B1 and then passed the answers from B1 to B2 and as expected got all the outputs as Zero matrices. We have included this function in our submission.


