Group Number - 37

Honor Code - 
I pledge by my honor that I have not received or given any unauthorized help for this assignment.


Contributions - 
(Meet Taraviya, mtaraviya, 150050002) - 100%
(Akash Trehan, atrehan, 150050031) - 100%
(Rohit Kumar Jena, rohitrango, 150050061) - 100%


Citations - 
-> num2cell(Used this for multiple assignments in one line) - https://www.gnu.org/software/octave/doc/v4.0.0/Creating-Cell-Arrays.html

->sin() for radian, sind() for degrees - https://www.gnu.org/software/octave/doc/v4.0.1/Trigonometry.html

->save and load variables - https://www.gnu.org/software/octave/doc/v4.0.0/Simple-File-I_002fO.html


Reflection Essay - 

A1 was pretty easy just using the simple refraction formulae and snell’s law. A2 had some complicated equations and we made some pretty silly mistakes. Also we ran into errors where we got division by zero on putting a particular starting point while not on others. Also we were getting zero in some cases. ’fsolve’ can get really tricky sometimes. We also tried using ‘fzero’ but it requires a range which we were not sure what to give so we went with ‘fsolve’. We saw a post on Piazza saying that we should use ‘fsolve’ with starting point 40 so we did that. For B1 it was easily done using Modular Mathematics. We struggled on creating matrix for B2 but finally came up with 2 algorithms one of which was very fast for large size matrices. We read that loops are slower in octave so we should somehow “vectorise” the code. So the faster algorithm uses matrix manipulation to arrive at a final matrix. We have put both in the file but the slower one is commented out. We got a bit late in submitting since we were just trying to improve and improve the code and documentation. We’ll take care of documentation and readme from next time. Overall it was a nice assignment and we enjoyed :D