Group Number 37

Members - (Meet Taraviya,150050002) (Akash Trehan,150050031) (Rohit Kumar Jena,150050061)

Meet Taraviya, Roll- 150050002
Honor Code-
I shall pledge to follow all the rules and guidelines issued by sir, while attempting the lab.

Akash Trehan, Roll- 150050031
Honor Code-
I pledge by my honor that I have not used unauthorized help in this assignment and have given my complete efforts.

Rohit Kumar Jena, Roll- 150050061
Honor Code-
I pledge to do my lab in a legitimate way, and not to provide or recieve any unauthorized help.

Contributions -
Meet Taraviya - 100%
Akash Trehan - 100%
Rohit Kumar Jena - 100%

----------------------------------------------------------------------------------
Task A
----------------------------------------------------------------------------------
We had practice with Github. So we could complete this task easily.

----------------------------------------------------------------------------------
Task B
----------------------------------------------------------------------------------
Comments added in the code for 1,2,3

----------------------------------------------------------------------------------
Extra Credit
----------------------------------------------------------------------------------
Tuples:

A tuple is a data structure in python. It is a type of sequence. Tuples are immutable as opposed to lists. Although tuples can contain mutable elements like lists as one of their elements. Tuples can contain variables with different datatypes as their elements.

(i)  Since tuples are immutable we can't add elements to it. It has no attribute append. Though we can create a new tuple.

/*
>>> a = (1,2,3)
>>> a.append(4)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: 'tuple' object has no attribute 'append'
*/

Similarly, we cannot modify the values in the tuple directly - 

/*
>>> x = (1,2)
>>> x[0]=3
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: 'tuple' object does not support item assignment
*/
 
-------------------------------------------------------------------------------------
(ii) We assigned an element as a list and tried to append elements into the list.

/*
>>> a=(1,[1,2,3],3)
>>> a[1]
[1, 2, 3]
>>> a[1].append(5)
>>> a
(1, [1, 2, 3, 5], 3)
*/

This is not a contradiction since the number and type of elements remain same.
List is stored in tuple through its iterator, whose value does not change by appending. If we see this way, the tuple is not changing.


----------------------------------------------------------------------------------
Citations
----------------------------------------------------------------------------------
None