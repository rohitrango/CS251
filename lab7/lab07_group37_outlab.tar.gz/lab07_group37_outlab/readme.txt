Group Number 37 - HOMEBREW

-------------------------------------------------------------------------------
                                 **NOTE**
-------------------------------------------------------------------------------
We are using 1 LATEDAY in this lab. Please do not apply penalty.


Members - (Meet Taraviya,150050002) (Akash Trehan,150050031) (Rohit Kumar Jena,150050061)

Meet Taraviya, Roll- 150050002
Honor Code-
I shall pledge to follow all the rules and guidelines issued by sir, while attempting the lab.

Akash Trehan, Roll- 150050031
Honor Code-
I pledge by my honor that I have not used unauthorized help in this assignment and have given my complete efforts.

Rohit Kumar Jena, Roll- 150050061
Honor Code-
I pledge to do my lab in a legitimate way, and not to provide or recieve any unauthorized help.

Contributions -
Meet Taraviya - 100%
Akash Trehan - 100%
Rohit Kumar Jena - 100%

Citations:
https://www.datacamp.com/community/tutorials/r-tutorial-apply-family#gs.6XMb6NQ

-----------------------------------
NOTE
-----------------------------------
taskD.R takes upto 20 seconds to execute. Please be patient and wait for output.

Reflection Essay:-

This was a tough one. Required a lot of effort. The marking scheme was very skewed. We were expecting more uniform distribution of marks among tasks.

-------------------------------------------------------------------------------
Task A
-------------------------------------------------------------------------------
This task was straightforward. We finished all the calculations. But we required some effort to search how to plot rays in R (because broken line was essentially 2 rays). We could not find anything that does not use a package. So we settled with line segments. Guess that's okay.

-------------------------------------------------------------------------------
Task B
-------------------------------------------------------------------------------
It took some time to understand the question, and what LOF is. The rest was again straightforward, and used previous concepts.
Useful concept although.


-------------------------------------------------------------------------------
Task C
-------------------------------------------------------------------------------
This one was a tough one to crack. Required a lot of statistical background. However, once we understood the question, the coding was easy.

-------------------------------------------------------------------------------
Task D
-------------------------------------------------------------------------------
NEVER, please NEVER give such questions. Such questions do not belong to this course. Especially the input was formatted very badly. It took a lot of time to figure out a way to convert it into usable format. Moreover, the question was poorly explained and left a lot of scope for confusions. Even after that, it required a lot of complicated coding, and algorithms. This was against the pattern we observed until now in CS 251.
However, conceptually, there was a lot to learn. We got an insight into how statistics is applied in life.