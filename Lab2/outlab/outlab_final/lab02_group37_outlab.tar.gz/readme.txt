Group Number 37

Members - (Meet Taraviya,150050002) (Akash Trehan,150050031) (Rohit Kumar Jena,150050061)

Meet Taraviya, Roll- 150050002
Honor Code-
I shall pledge to follow all the rules and guidelines issued by sir, while attempting the lab.

Akash Trehan, Roll- 150050031
Honor Code-
I pledge by my honor that I have not used unauthorized help in this assignment and have given my complete efforts.

Rohit Kumar Jena, Roll- 150050061
Honor Code-
I pledge to do my lab in a legitimate way, and not to provide or recieve any unauthorized help.

Contributions -
Meet Taraviya - 100%
Akash Trehan - 100%
Rohit Kumar Jena - 100%

Citations -
Pokemon Database and images - http://pokemondb.net/
SVG Icons - www.flaticon.com


Usage - Inkscape allows to import only one page of a pdf at a time. So we only uploaded the changed page in pdf.


Note: We have attempted both the extra tasks. Please refer to the relevant files that you asked for in the assignment document. The links to the extra task of Task D is there in the folder `pdf_bonus` along with the original files.

Reflection Essay -
In task A, the purpose was to revamp the features and add the Materialize library. We wanted a minimalistic theme, so we focused on content. The CSS wrapper used was from Materialize, and we didnot use a background because we didn't want to make it too fancy or something. We lacked on content, but tried our best to fill the pages with only `relevant` content.

Task B was fun. Javascript wasn't a problem but RegEx was :P. After a lot of silly mistakes, we finally arrived at the perfect(hopefully) regular expressions for checking various details. On-fly form felt good to implement. Cross-site scripting prevention while easy to implement was quite interesting to read about!

In task C, we had to make our own accordion. We used Materialize only for the CSS wrapper and font (according to the outlab pdf) but the entire css and js for the accordion was built by us. We used the same hierarchy of accordion as used by Materialize - the panels of a certain accordion are NOT related to the panels of the other accordion .i.e. the code is general, so if you use 2 or more accordions in the same page, they won't conflict with each other, and there can be any number of panels inside an accordion. This is a generalized code and can be directly used in a CSS library if we decide to build one :P 

In task D, first we struggled regarding getting the dimensions right. But we came up with a trick and managed to get proportional dimensions. The design of first floor is tricky to explain using only simple shapes.
We had to try really hard to get 5 pdfs to edit. For the pdfs, everything went cool but editting text was tricky. We realized that inkscape is buggy.