Group Number 37

Members - (Meet Taraviya,150050002) (Akash Trehan,150050031) (Rohit Kumar Jena,150050061)

-----------------------------------------------------------------------------------------------

Meet Taraviya, Roll- 150050002
Honor Code-
I shall pledge to follow all the rules and guidelines issued by sir, while attempting thelab.

Akash Trehan, Roll- 150050031
Honor Code-
I pledge by my honor that I have not used unauthorized help in this assignment and have given my complete efforts.

Rohit Kumar Jena, Roll- 150050061
Honor Code-
I pledge to do my lab in a legitimate way, and not to provide or recieve any unauthorizedhelp.

-------------------------------------------------------------------------------------------------

Contributions -
Meet Taraviya - 100%
Akash Trehan - 100%
Rohit Kumar Jena - 100%

-------------------------------------------------------------------------------------------------

Citations:
None

-------------------------------------------------------------------------------------------------

TaskE:
No extra files are there. All functionality is present in one file itself.

-------------------------------------------------------------------------------------------------

Reflection Essay:

The was a pretty long lab and included diverse things. We really enjoyed learning the new concepts(Threads!) except swing which reminded us of Box2D. Java as a language is okayish. Very Verbose as you said in class. We, on the other hand, like smart compilers which can interpret things based on context. Overall it was a nice lab!

The course as a whole has been great! A big thanks to Sharat Sir and all the TAs!
