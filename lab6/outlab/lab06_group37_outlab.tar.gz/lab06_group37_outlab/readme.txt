Group Number 37

Members - (Meet Taraviya,150050002) (Akash Trehan,150050031) (Rohit Kumar Jena,150050061)

Meet Taraviya, Roll- 150050002
Honor Code-
I shall pledge to follow all the rules and guidelines issued by sir, while attempting the lab.

Akash Trehan, Roll- 150050031
Honor Code-
I pledge by my honor that I have not used unauthorized help in this assignment and have given my complete efforts.

Rohit Kumar Jena, Roll- 150050061
Honor Code-
I pledge to do my lab in a legitimate way, and not to provide or recieve any unauthorized help.

Contributions -
Meet Taraviya - 100%
Akash Trehan - 100%
Rohit Kumar Jena - 100%

----------------------------------------------------------------
Citations
----------------------------------------------------------------
1. https://dl.acm.org
2. https://www.latex-tutorial.com/
3. http://tex.stackexchange.com/questions/329629/factorial-program-in-latex-without-using-any-package (Question asked by us)

----------------------------------------------------------------
Reflection Essay
----------------------------------------------------------------

Task A0
The task was really easy. One search in stackoverflow and boom - We knew what to do! In addition to adding the theta and mu symbols, we have removed the black box that was hiding the 'w' and the grey box.

Task A1
This was a long task. Some of the things were pretty simple to implement while others were rather hard and took a lot of googling. There were multiple methods to do everything and every stack exchange answer had a different approach. This was what made it hard. It was a fun process overall though and we learnt lots of different stuff.

TaskA2
The task wasn't too difficult, apart from the research that had to be done. On the positive side, we got to know about the shortest path algorithm, (we all knew the other two :) ). Citing the appropriate resources is something that we spent time upon. We also included the Makefile that would make things easier for you :)

Task A3
Fibonacci was easy, as it just required addition. Factorial took some time, as we could not find how to multiply. Finally, we discovered \numexpr, which saved the day.

TaskB
Apart from the report.txt file, we would like to add that this feature of gnuplot (fit) is really powerful and incredibly easy to use.

