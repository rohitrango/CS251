#! /bin/sh

while true; do sleep 1; done
