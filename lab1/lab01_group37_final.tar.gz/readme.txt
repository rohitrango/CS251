Group Number - 37

Honor Code - 
I pledge by my honor that I have not received or given any unauthorized help for this assignment.

Contributions - 
(Meet Taraviya, mtaraviya, 150050002) - 100%
(Akash Trehan, atrehan, 150050031) - 100%
(Rohit Kumar Jena, rohitrango, 150050061) - 100%

Usage - 
Run the file named `refraction.m` in octave.

Citations - 
For writing to file - https://www.gnu.org/software/octave/doc/v4.0.1/Formatted-Output.html#XREFfprintf

Feedback - 
We really enjoyed the first in-lab. The algorithm of the second question is interesting.

Reflection Essay - 

Initially we were trying to simplify the equations manually and then only calculate the solution using octave. But then we found the `fsolve` function in Octave's documentation. We had some problems trying to keep the functions and the commands in the same file but later discovered that functions must be kept in separated files with the same name as the function. After struggling with printing a single line output, we finally got it! 
