[x,info] = fsolve('f',45); % Solving for x using initial guess 45 degrees
% Computes the answer in degrees
fid = fopen ('output_inlab_task_01.txt', 'w'); % Writing output to file 
fprintf (fid, '%06f', x);
fclose (fid);